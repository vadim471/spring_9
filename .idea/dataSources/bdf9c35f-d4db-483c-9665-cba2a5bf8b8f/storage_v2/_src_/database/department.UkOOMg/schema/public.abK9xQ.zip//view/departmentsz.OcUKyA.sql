create view departmentsz(dep_code, dep_name, total_salary) as
SELECT d.department_code                             AS dep_code,
       d.department_name                             AS dep_name,
       (SELECT sum(e.emp_salary) AS sum
        FROM employers e
        WHERE d.department_code = e.department_code) AS total_salary
FROM department_info d;

alter table departmentsz
    owner to postgres;

