create materialized view employer as
SELECT d.department_code,
       d.department_name,
       (SELECT count(e.employee_code) AS count
        FROM employers e
        WHERE d.department_code = e.department_code) AS emp_lot
FROM department_info d;

alter materialized view employer owner to postgres;

